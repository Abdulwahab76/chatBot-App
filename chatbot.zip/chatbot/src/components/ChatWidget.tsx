import React, { useEffect, useRef, useState } from "react";
import styles from "../styles/chat.module.css";
import { askQuestion } from "../api/windmason";

type Role = "user" | "assistant";

interface Message {
    id: string;
    role: Role;
    text: string;
    ts: number;
}

function uid(): string {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function ChatWidget() {
    const [open, setOpen] = useState(true);
    const [messages, setMessages] = useState<Message[]>(() => {
        try {
            const raw = localStorage.getItem("chat_demo_history");
            return raw ? (JSON.parse(raw) as Message[]) : [];
        } catch {
            return [];
        }
    });
    const [value, setValue] = useState("");
    const [loading, setLoading] = useState(false);
    const [openQuestions, setOpenQuestions] = useState(true);
    const [isEnlarged, setIsEnlarged] = useState(false);

    const listRef = useRef<HTMLDivElement | null>(null);
    const inputRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
        localStorage.setItem("chat_demo_history", JSON.stringify(messages));
        requestAnimationFrame(() => {
            if (listRef.current) {
                listRef.current.scrollTop = listRef.current.scrollHeight;
            }
        });
    }, [messages]);

    useEffect(() => {
        if (open) {
            setTimeout(() => inputRef.current?.focus(), 200);
        }
    }, [open]);

    const toggleOpen = () => {
        if (!open) {
            const audio = new Audio('/pop-cartoon.mp3');
            audio.play().catch((e) => {
                console.warn('Audio play failed:', e);
            });
        }
        setOpen((v) => !v);
        if (open) {
            setOpenQuestions(true); // Show questions when closing
        }
    };

    const pushMessage = (role: Role, text: string) => {
        const m: Message = { id: uid(), role, text, ts: Date.now() };
        setMessages((s) => [...s, m]);
        return m;
    };

    const send = async () => {
        const trimmed = value.trim();
        if (!trimmed) return;
        pushMessage("user", trimmed);
        setValue("");
        setLoading(true);

        try {
            // askQuestion handles fallback & timeouts
            const reply = await askQuestion(trimmed);
            // optional: small delay for "typing" feel
            await new Promise((r) => setTimeout(r, 250));
            const audio = new Audio('./new-notification.mp3');
            audio.play().catch((e) => {
                console.warn('Audio play failed:', e);
            });
            pushMessage("assistant", reply);
        } catch (err: any) {
            console.error("askQuestion error:", err);
            pushMessage("assistant", "Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const handleEnter = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            send();
        }
    };

    // const clearHistory = () => {
    //     setMessages([]);
    //     localStorage.removeItem("chat_demo_history");
    // };
    const handlePresetClick = (text: string) => {
        setValue(text); // Set the input field value
        if (!open) toggleOpen(); // Open chat if it's closed
        inputRef.current?.focus(); // Focus input
    };

    useEffect(() => {
        if (isEnlarged) {
            document.body.style.overflow = "hidden";
        } else {
            document.body.style.overflow = "";
        }
    }, [isEnlarged]);


    return (
        <div>
            {/* Preset Floating Questions */}
            {openQuestions && <div className={styles.floatingQuestions}>
                <span onClick={() => setOpenQuestions(false)} style={{ display: 'flex', marginLeft: 'auto', color: 'gray', cursor: 'pointer' }}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-x-icon lucide-x"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg></span>
                <button onClick={() => handlePresetClick("What are your hours?")}>What are your hours?</button>
                <button onClick={() => handlePresetClick("How can I contact support?")}>Contact support</button>
                <button onClick={() => handlePresetClick("Tell me about your services.")}>Our services</button>
            </div>}

            {/* Floating Chat Button */}
            <button
                aria-expanded={open}
                className={`${styles.fab} ${open ? styles.fabOpen : ""}`}
                onClick={toggleOpen}
                title={open ? "Close chat" : "Open chat"}
            >
                <span className={styles.fabIcon}>
                    {open ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
                    ) : (
                        <img src="/bot.svg" alt="" />
                    )}
                </span>
            </button>


            {/* Chat panel */}
            <div
                className={`${styles.panel} ${open ? styles.panelOpen : styles.panelClosed} ${isEnlarged ? styles.panelEnlarged : ""}`}
                role="dialog"
                aria-hidden={!open}
            >
                <div className={styles.header}>
                    <div style={{ display: "flex", gap: '10px' }}>
                        <img src="/bot.svg" alt="" />
                        <div>
                            <div className={styles.title}>Chatbot</div>
                            <div className={styles.status}>
                                <span></span>
                                Online
                            </div>
                        </div>
                    </div>
                    <div className={styles.headerActions}>
                        {/* <button onClick={clearHistory} className={styles.iconBtn} title="Clear">
                            🧹
                        </button> */}
                        <button
                            style={{
                                backgroundColor: 'transparent',
                                border: 'none',
                                cursor: 'pointer',
                                padding: '5px',
                                color: 'white',
                            }}
                            onClick={() => setIsEnlarged((prev) => !prev)} // Toggle enlarge
                            className={styles.iconBtn}
                            title={isEnlarged ? "Minimize Chat" : "Enlarge Chat"}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" strokeWidth="2"
                                strokeLinecap="round" strokeLinejoin="round"
                                className="lucide lucide-maximize2-icon lucide-maximize-2">
                                <path d="M15 3h6v6" />
                                <path d="m21 3-7 7" />
                                <path d="m3 21 7-7" />
                                <path d="M9 21H3v-6" />
                            </svg>
                        </button>

                        <button onClick={toggleOpen} className={styles.iconBtn} title="Close">
                            <img src="/arrow.svg" alt="" />
                        </button>
                    </div>
                </div>

                <div className={styles.messages} ref={listRef}>
                    {messages.length === 0 && (
                        <div className={styles.emptyState}>
                            <strong>Welcome!</strong>
                            <p>Ask something like <strong>“What services does Windmason provide”</strong></p>
                        </div>
                    )}

                    {messages.map((m) => (
                        <div>
                            <div key={m.id} className={`${styles.message} ${m.role === "user" ? styles.user : styles.assistant}`}>
                                <div className={styles.bubble}>
                                    <div className={styles.msgText}>{m.text}</div>
                                    <div className={styles.msgTs}>{new Date(m.ts).toLocaleTimeString()}</div>
                                </div>
                            </div>
                            {m.role === 'user' ? '' : <div style={{ width: '35px', height: '35px', backgroundColor: '#EE0D08', borderRadius: '25px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '10px' }}>
                                <img width={25} height={25} src="/bot.svg" alt="" />
                            </div>}
                        </div>
                    ))}

                    {loading && (
                        <div className={`${styles.message} ${styles.assistant}`}>
                            <div className={styles.bubble}>
                                <span className={styles.typing}>
                                    <i />
                                    <i />
                                    <i />
                                </span>
                            </div>
                        </div>
                    )}
                </div>

                <form
                    className={styles.inputRow}
                    onSubmit={(e) => {
                        e.preventDefault();
                        send();
                    }}
                >
                    <div style={{ display: "flex", flex: 1, backgroundColor: '#F3F5F6', alignItems: 'center', borderRadius: '20px', padding: '5px 10px', height: '80%' }}>
                        <input
                            ref={inputRef}
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            onKeyDown={handleEnter}
                            placeholder="Ask a question..."
                            className={styles.textarea}
                            aria-label="Ask a question..."
                        />
                        <button type="submit" className={styles.sendBtn} disabled={loading || !value.trim()}>
                            {loading ? "..." : <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-send-horizontal-icon lucide-send-horizontal"><path d="M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z" /><path d="M6 12h16" /></svg>}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
